import 'package:flutter/material.dart';

const kPrimaryColor = Color.fromARGB(255, 71, 54, 111);
const double kDefaultPadding = 20.0;
// const kDefaultBorderRadius = BorderRadius.circular(10)
