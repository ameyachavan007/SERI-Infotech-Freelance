class ChangePasswordDataCheck {

}